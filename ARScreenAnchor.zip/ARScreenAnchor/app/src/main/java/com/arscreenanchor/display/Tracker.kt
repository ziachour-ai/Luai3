package com.arscreenanchor.display

import android.content.Context
import android.hardware.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

/** Suivi de tête via les capteurs de la tablette (repli). */
class Tracker(ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val r = FloatArray(9); private val r2 = FloatArray(9); private val o = FloatArray(3)

    fun start() {
        sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }
    fun stop() = sm.unregisterListener(this)

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(r, e.values)
        // Tablette tenue à la verticale : on remappe les axes pour éviter le blocage de cardan.
        SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2)
        SensorManager.getOrientation(r2, o)
        Anchor.yaw = Math.toDegrees(o[0].toDouble()).toFloat()
        Anchor.pitch = Math.toDegrees(o[1].toDouble()).toFloat()
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

object Usb {
    const val VENDOR_ID = 0x3318 // XREAL / Nreal (à vérifier avec votre modèle)
    fun find(ctx: Context): UsbDevice? =
        (ctx.getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values.firstOrNull { it.vendorId == VENDOR_ID }
}
