package com.arscreenanchor.display

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Bundle
import android.view.*
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tan

/** Écran affiché dans les lunettes : copie de la tablette, déplacée selon l'ancrage. */
class GlassesPresentation(
    ctx: Context, d: Display, private val proj: MediaProjection,
    private val w0: Int, private val h0: Int, private val dpi: Int
) : Presentation(ctx, d) {
    private var vd: VirtualDisplay? = null
    private var st: SurfaceTexture? = null
    private lateinit var tv: TextureView
    private var alive = true
    private var shownLandscape = Anchor.landscape
    private val hi = max(w0, h0)
    private val lo = min(w0, h0)

    private fun bufSize(land: Boolean): Pair<Int, Int> {
        var w = if (land) hi else lo
        var h = if (land) lo else hi
        val sc = min(1f, 1920f / max(w, h))          // limite la résolution pour la fluidité
        w = ((w * sc).toInt() / 2) * 2
        h = ((h * sc).toInt() / 2) * 2
        return Pair(w, h)
    }

    /** Applique la forme (paysage / portrait) à l'écran virtuel. */
    private fun shape() {
        val land = Anchor.landscape
        shownLandscape = land
        val (bw, bh) = bufSize(land)
        val dm = context.resources.displayMetrics
        tv.layoutParams = if (land) FrameLayout.LayoutParams(dm.widthPixels, dm.widthPixels * bh / bw, Gravity.CENTER)
                          else FrameLayout.LayoutParams(dm.heightPixels * bw / bh, dm.heightPixels, Gravity.CENTER)
        st?.setDefaultBufferSize(bw, bh)
        vd?.resize(bw, bh, dpi)
    }

    private fun px(deg: Float, f: Float): Float = f * tan(Math.toRadians(deg.coerceIn(-80f, 80f).toDouble())).toFloat()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dw = context.resources.displayMetrics.widthPixels
        tv = TextureView(context)
        val root = FrameLayout(context).apply { setBackgroundColor(Color.BLACK) }
        root.addView(tv, FrameLayout.LayoutParams(1, 1))
        setContentView(root)
        shape()

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(t: SurfaceTexture, a: Int, b: Int) {
                st = t
                val (bw, bh) = bufSize(Anchor.landscape)
                t.setDefaultBufferSize(bw, bh)
                vd = proj.createVirtualDisplay("AR", bw, bh, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, Surface(t), null, null)
            }
            override fun onSurfaceTextureSizeChanged(t: SurfaceTexture, a: Int, b: Int) {}
            override fun onSurfaceTextureDestroyed(t: SurfaceTexture): Boolean { vd?.release(); return true }
            override fun onSurfaceTextureUpdated(t: SurfaceTexture) {}
        }
        // distance focale en pixels pour un champ horizontal de FOV degrés
        val focal = (dw / 2f) / tan(Math.toRadians(Anchor.FOV / 2.0)).toFloat()
        Choreographer.getInstance().postFrameCallback(object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (!alive) return
                if (Anchor.landscape != shownLandscape) shape()
                val s = Anchor.sizePct / 100f
                tv.scaleX = s; tv.scaleY = s
                tv.translationX = px(Anchor.offsetYaw() * Anchor.gain, focal)
                tv.translationY = -px(Anchor.offsetPitch() * Anchor.gain, focal)
                Choreographer.getInstance().postFrameCallback(this)
            }
        })
    }
    override fun onStop() { alive = false; vd?.release(); super.onStop() }
}
