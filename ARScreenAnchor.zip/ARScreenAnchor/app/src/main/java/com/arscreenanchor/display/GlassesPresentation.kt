package com.arscreenanchor.display

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Bundle
import android.view.*
import android.widget.FrameLayout

/** Écran affiché dans les lunettes : copie de la tablette, déplacée selon l'ancrage. */
class GlassesPresentation(
    ctx: Context, d: Display, private val proj: MediaProjection,
    private val w: Int, private val h: Int, private val dpi: Int
) : Presentation(ctx, d) {
    private var vd: VirtualDisplay? = null
    private var alive = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dw = context.resources.displayMetrics.widthPixels
        val tv = TextureView(context)
        val root = FrameLayout(context).apply { setBackgroundColor(Color.BLACK) }
        root.addView(tv, FrameLayout.LayoutParams(dw, dw * h / w, Gravity.CENTER))
        setContentView(root)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, a: Int, b: Int) {
                st.setDefaultBufferSize(w, h)
                vd = proj.createVirtualDisplay("AR", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, Surface(st), null, null)
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, a: Int, b: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { vd?.release(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        val pxPerDeg = dw / Anchor.FOV
        Choreographer.getInstance().postFrameCallback(object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (!alive) return
                val s = Anchor.sizePct / 100f
                tv.scaleX = s; tv.scaleY = s
                tv.translationX = Anchor.offsetYaw() * pxPerDeg
                tv.translationY = -Anchor.offsetPitch() * pxPerDeg
                Choreographer.getInstance().postFrameCallback(this)
            }
        })
    }
    override fun onStop() { alive = false; vd?.release(); super.onStop() }
}
